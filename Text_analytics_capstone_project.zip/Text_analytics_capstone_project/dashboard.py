# dashboard.py
"""
Tourist Experience Analytics Dashboard (Final Clean Version)
✅ Matches dataset columns:
   source, destination, clean_text, link, date, sentiment_score, sentiment_label
✅ Includes:
   - Sentiment
   - Keywords
   - Emotions
   - Topics
   - Issues & Behavior
   - Destination Summaries
   - Destination Explorer
   - Map View 🌍
"""

import os
import io
import time
import streamlit as st
import pandas as pd
import plotly.express as px
from geopy.geocoders import Nominatim
from geopy.exc import GeocoderTimedOut

# ----------------- Config -----------------
DATA_PATH = "data_raw"
st.set_page_config(page_title="Tourist Experience Dashboard", layout="wide", page_icon="🌏")
# ------------------------------------------

def load_csv(filename):
    path = os.path.join(DATA_PATH, filename)
    if os.path.exists(path):
        try:
            return pd.read_csv(path)
        except Exception as e:
            st.error(f"Error loading {filename}: {e}")
            return pd.DataFrame()
    else:
        return pd.DataFrame()

# ---------- Load datasets ----------
sentiment_df = load_csv("usecase1_sentiment_analysis.csv")
keywords_df = load_csv("usecase2_keyword_extraction.csv")
emotion_df = load_csv("usecase3_emotion_detection.csv")
topics_df = load_csv("usecase4_topic_keywords.csv")
topic_labeled_df = load_csv("usecase4_topic_named.csv")
issues_df = load_csv("usecase5_detected_issues.csv")
behavior_df = load_csv("usecase5_behavior_analysis.csv")
summary_df = load_csv("usecase5_destination_summary.csv")

# ---------- Sidebar filters ----------
st.sidebar.header("Filters")
all_destinations = sorted(
    list(
        set(
            sum(
                [
                    df["destination"].dropna().unique().tolist()
                    for df in [sentiment_df, keywords_df, emotion_df, topic_labeled_df, summary_df]
                    if not df.empty and "destination" in df.columns
                ],
                [],
            )
        )
    )
)
selected_dest = st.sidebar.multiselect("Select destination(s)", options=all_destinations, default=all_destinations[:6])
st.sidebar.markdown("---")

def to_csv_bytes(df):
    buf = io.BytesIO()
    df.to_csv(buf, index=False, encoding="utf-8")
    buf.seek(0)
    return buf

def filter_by_destination(df, col="destination"):
    if df.empty or col not in df.columns:
        return df
    if not selected_dest:
        return df
    return df[df[col].isin(selected_dest)]

# ---------- Page layout ----------
st.title("🌏 Tourist Experience Analytics Dashboard")
st.markdown("Explore tourist feedback, NLP insights, and real-time analytics from destinations across India.")

tabs = st.tabs([
    "Sentiment",
    "Keywords",
    "Emotions",
    "Topics",
    "Issues & Behavior",
    "Destination Summaries",
    "Destination Explorer",
    "Map View 🌍"
])

# ------------ TAB 1: Sentiment ------------
with tabs[0]:
    st.header("🧠 Sentiment Overview")
    if sentiment_df.empty:
        st.warning("Missing: usecase1_sentiment_analysis.csv")
    else:
        df = filter_by_destination(sentiment_df)
        if "sentiment_score" in df.columns:
            df["sentiment_score"] = pd.to_numeric(df["sentiment_score"], errors="coerce")

            # Detect correct label column
            label_col = "sentiment_label" if "sentiment_label" in df.columns else "sentoment_lebel"

            fig = px.bar(
                df,
                x="destination",
                y="sentiment_score",
                color=label_col,
                title="Sentiment Score per Destination",
                color_discrete_sequence=["red", "yellow", "green"]
            )
            st.plotly_chart(fig, use_container_width=True)

        st.dataframe(df)
        st.download_button("Download Sentiment Data", data=to_csv_bytes(df), file_name="sentiment_filtered.csv")

# ------------ TAB 2: Keywords ------------
with tabs[1]:
    st.header("🔑 Keyword Extraction")
    if keywords_df.empty:
        st.warning("Missing: usecase2_keyword_extraction.csv")
    else:
        df = filter_by_destination(keywords_df)
        df["keyword_count"] = df["top_keywords"].fillna("").apply(lambda x: len(str(x).split(", ")))
        fig = px.bar(df, x="destination", y="keyword_count", title="Number of Keywords per Destination")
        st.plotly_chart(fig, use_container_width=True)
        st.dataframe(df)
        st.download_button("Download Keyword Data", data=to_csv_bytes(df), file_name="keywords_filtered.csv")

# ------------ TAB 3: Emotions ------------
with tabs[2]:
    st.header("🎭 Emotion Detection")
    if emotion_df.empty:
        st.warning("Missing: usecase3_emotion_detection.csv")
    else:
        df = filter_by_destination(emotion_df)
        if "dominant_emotion" in df.columns:
            ec = df["dominant_emotion"].value_counts().reset_index()
            ec.columns = ["emotion", "count"]
            fig = px.pie(ec, names="emotion", values="count", title="Overall Emotion Distribution")
            st.plotly_chart(fig, use_container_width=True)
        st.dataframe(df)
        st.download_button("Download Emotion Data", data=to_csv_bytes(df), file_name="emotions_filtered.csv")

# ------------ TAB 4: Topics ------------
with tabs[3]:
    st.header("🧩 Topic Detection")
    if topics_df.empty:
        st.warning("Missing: usecase4_topic_keywords.csv")
    else:
        st.subheader("Top Topics")
        st.dataframe(topics_df)
    if not topic_labeled_df.empty:
        df = filter_by_destination(topic_labeled_df)
        if "Topic_Label" in df.columns:
            counts = df["Topic_Label"].value_counts().reset_index()
            counts.columns = ["Topic_Label", "count"]
            fig = px.bar(counts, x="count", y="Topic_Label", orientation="h", title="Topic Distribution")
            st.plotly_chart(fig, use_container_width=True)
        st.download_button("Download Topic Data", data=to_csv_bytes(df), file_name="topics_filtered.csv")

# ------------ TAB 5: Issues & Behavior ------------
with tabs[4]:
    st.header("⚠️ Issues & Behavior")
    cols = st.columns(2)
    with cols[0]:
        if issues_df.empty:
            st.warning("Missing: usecase5_detected_issues.csv")
        else:
            fig = px.bar(issues_df, x="count", y="issue_type", orientation="h", title="Top Reported Issues")
            st.plotly_chart(fig, use_container_width=True)
            st.dataframe(issues_df)
    with cols[1]:
        if behavior_df.empty:
            st.warning("Missing: usecase5_behavior_analysis.csv")
        else:
            fig = px.bar(behavior_df, x="count", y="behavior_type", orientation="h", title="Behavior Patterns")
            st.plotly_chart(fig, use_container_width=True)
            st.dataframe(behavior_df)

# ------------ TAB 6: Summaries ------------
with tabs[5]:
    st.header("🗺 Destination Summaries")
    if summary_df.empty:
        st.warning("Missing: usecase5_destination_summary.csv")
    else:
        df = filter_by_destination(summary_df)
        for _, row in df.iterrows():
            with st.expander(f"📍 {row['destination']}  — Avg Sentiment: {row.get('average_sentiment', 'N/A')}"):
                st.write(row.get("summary", "No summary available."))
        st.download_button("Download Summaries", data=to_csv_bytes(df), file_name="summaries.csv")

# ------------ TAB 7: Destination Explorer ------------
with tabs[6]:
    st.header("🌐 Destination Explorer")
    if not all_destinations:
        st.warning("No destination data available.")
    else:
        dest_choice = st.selectbox("Select a destination to explore", options=all_destinations)
        st.markdown(f"### 📍 Insights for **{dest_choice}**")

        if not sentiment_df.empty and dest_choice in sentiment_df["destination"].values:
            s_row = sentiment_df[sentiment_df["destination"] == dest_choice]
            label_col = "sentiment_label" if "sentiment_label" in s_row.columns else "sentoment_lebel"
            st.metric("Sentiment Score", round(float(s_row["sentiment_score"].values[0]), 3))
            st.metric("Sentiment Label", s_row[label_col].values[0])

        if not keywords_df.empty and dest_choice in keywords_df["destination"].values:
            kw = keywords_df[keywords_df["destination"] == dest_choice]["top_keywords"].values[0].split(", ")
            st.markdown("#### 🔑 Top Keywords:")
            st.write(", ".join(kw[:15]))

        if not emotion_df.empty:
            e_df = emotion_df[emotion_df["destination"] == dest_choice]
            if not e_df.empty and "dominant_emotion" in e_df.columns:
                ec = e_df["dominant_emotion"].value_counts().reset_index()
                ec.columns = ["Emotion", "Count"]
                fig = px.pie(ec, names="Emotion", values="Count", title=f"Emotions in {dest_choice}")
                st.plotly_chart(fig, use_container_width=True)

        if not topic_labeled_df.empty:
            t_df = topic_labeled_df[topic_labeled_df["destination"] == dest_choice]
            if not t_df.empty and "Topic_Label" in t_df.columns:
                counts = t_df["Topic_Label"].value_counts().reset_index()
                counts.columns = ["Topic_Label", "Count"]
                fig = px.bar(counts, x="Count", y="Topic_Label", orientation="h",
                             title=f"Topics Discussed in {dest_choice}")
                st.plotly_chart(fig, use_container_width=True)

# ------------ TAB 8: Map View 🌍 ------------
with tabs[7]:
    st.header("📍 Map View of Tourist Destinations")

    if sentiment_df.empty:
        st.warning("Sentiment data required for map view.")
    else:
        st.info("🟢 Green = Positive | 🟡 Neutral | 🔴 Negative sentiment intensity")
        df = sentiment_df.copy()

        if "sentiment_score" in df.columns:
            df["sentiment_score"] = pd.to_numeric(df["sentiment_score"], errors="coerce").fillna(0)
        else:
            st.error("No 'sentiment_score' column found in dataset.")
            st.stop()

        df["sentiment_score"] = df["sentiment_score"].clip(-1, 1)

        geolocator = Nominatim(user_agent="tourist_map")

        @st.cache_data(show_spinner=False)
        def get_coordinates(destinations):
            coords = {}
            for d in destinations:
                try:
                    loc = geolocator.geocode(f"{d}, India", timeout=10)
                    if loc:
                        coords[d] = (loc.latitude, loc.longitude)
                    time.sleep(1)
                except GeocoderTimedOut:
                    continue
            return coords

        coords = get_coordinates(df["destination"].unique())
        df["lat"] = df["destination"].map(lambda x: coords.get(x, (None, None))[0])
        df["lon"] = df["destination"].map(lambda x: coords.get(x, (None, None))[1])
        df = df.dropna(subset=["lat", "lon"])

        label_col = "sentiment_label" if "sentiment_label" in df.columns else "sentoment_lebel"

        fig = px.scatter_mapbox(
            df,
            lat="lat",
            lon="lon",
            size=abs(df["sentiment_score"]) + 0.3,
            color="sentiment_score",
            color_continuous_scale=[(0, "red"), (0.5, "yellow"), (1, "green")],
            range_color=(-1, 1),
            hover_name="destination",
            hover_data={"sentiment_score": True, label_col: True},
            title="Tourist Sentiment Map (India)",
            zoom=4,
            mapbox_style="carto-positron"
        )

        fig.update_layout(
            coloraxis_colorbar=dict(
                title="Sentiment Intensity",
                tickvals=[-1, 0, 1],
                ticktext=["Negative", "Neutral", "Positive"]
            )
        )

        st.plotly_chart(fig, use_container_width=True)

st.success("✅ Dashboard ready! Explore all NLP insights and the interactive map.")
