# usecase1_sentiment_analysis.py
"""
Use Case 1: Sentiment Analysis of Tourist Experiences
Input : data_raw/tourist_experience_cleaned.csv
Output: data_raw/usecase1_sentiment_analysis.csv
"""

import pandas as pd
import os
import nltk
from nltk.sentiment.vader import SentimentIntensityAnalyzer

# Download the VADER lexicon (only first run)
nltk.download("vader_lexicon")

INPUT_FILE = "data_raw/tourist_experience_cleaned.csv"
OUTPUT_FILE = "data_raw/usecase1_sentiment_analysis.csv"

def analyze_sentiment(text):
    """Return compound sentiment score"""
    analyzer = SentimentIntensityAnalyzer()
    scores = analyzer.polarity_scores(str(text))
    return scores["compound"]

def label_sentiment(score):
    """Convert numeric score → text label"""
    if score >= 0.05:
        return "Positive"
    elif score <= -0.05:
        return "Negative"
    else:
        return "Neutral"

def main():
    print("🧠 Starting Sentiment Analysis...")
    df = pd.read_csv(INPUT_FILE)
    print(f"📄 Loaded {len(df)} records")

    # Run VADER sentiment on each cleaned text
    df["sentiment_score"] = df["clean_text"].apply(analyze_sentiment)
    df["sentiment_label"] = df["sentiment_score"].apply(label_sentiment)

    # Summarize sentiment by destination
    summary = (
        df.groupby("destination")["sentiment_label"]
        .value_counts(normalize=True)
        .unstack(fill_value=0)
        .reset_index()
    )

    os.makedirs("data_raw", exist_ok=True)
    df.to_csv(OUTPUT_FILE, index=False, encoding="utf-8")

    print("\n✅ Sentiment analysis complete!")
    print(f"💾 Results saved → {OUTPUT_FILE}")
    print("\n📊 Destination Sentiment Overview (sample):")
    print(summary.head(10))

if __name__ == "__main__":
    main()



#Visualization

import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("data_raw/usecase1_sentiment_analysis.csv")
sentiment_summary = df.groupby("destination")["sentiment_label"].value_counts(normalize=True).unstack(fill_value=0)
sentiment_summary.plot(kind="bar", stacked=True, figsize=(10,6))
plt.title("Tourist Sentiment by Destination")
plt.ylabel("Proportion of Reviews")
plt.savefig("data_raw/usecase1_sentiment_chart.png", dpi=300)
plt.show()
