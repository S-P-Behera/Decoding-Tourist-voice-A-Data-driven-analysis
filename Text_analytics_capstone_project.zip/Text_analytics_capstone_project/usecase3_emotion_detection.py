# ---------- Use Case 3: Emotion Detection (Improved Hybrid Version) ----------
"""
Detects emotional tones (Joy, Anger, Fear, Sadness, Surprise, Trust)
Input : data_raw/tourist_experience_cleaned.csv
Output:
 - data_raw/usecase3_emotion_detection.csv  → review-level results
 - data_raw/usecase3_emotion_summary.csv    → aggregated by destination
"""

import pandas as pd
from nrclex import NRCLex
from textblob import TextBlob
from tqdm import tqdm
import os

# ---------- CONFIG ----------
INPUT_FILE = "data_raw/tourist_experience_cleaned.csv"
OUTPUT_FILE = "data_raw/usecase3_emotion_detection.csv"
SUMMARY_FILE = "data_raw/usecase3_emotion_summary.csv"
# ----------------------------

def detect_emotions(text):
    """Return top detected emotion from NRCLex + fallback via TextBlob polarity"""
    text = str(text)
    if not text.strip():
        return "neutral"

    # Try NRCLex first
    emotion = NRCLex(text)
    emotion_scores = emotion.raw_emotion_scores

    if emotion_scores:
        dominant = max(emotion_scores, key=emotion_scores.get)
        return dominant

    # Fallback using sentiment polarity
    polarity = TextBlob(text).sentiment.polarity
    if polarity > 0.2:
        return "joy"
    elif polarity < -0.2:
        return "anger"
    else:
        return "neutral"


def main():
    print("🎭 Starting Enhanced Emotion Detection...")
    df = pd.read_csv(INPUT_FILE)
    print(f"📄 Loaded {len(df)} cleaned reviews")

    tqdm.pandas()
    df["dominant_emotion"] = df["clean_text"].progress_apply(detect_emotions)

    # ✅ Confirm detection worked
    print("\n🧩 Emotion Distribution (All Reviews):")
    print(df["dominant_emotion"].value_counts())

    # ✅ Save full dataset
    os.makedirs("data_raw", exist_ok=True)
    df.to_csv(OUTPUT_FILE, index=False, encoding="utf-8")
    print(f"\n💾 Full data with emotions saved → {OUTPUT_FILE}")

    # ✅ Summarize emotion by destination
    emotion_summary = (
        df.groupby("destination")["dominant_emotion"]
        .value_counts(normalize=True)
        .unstack(fill_value=0)
        .reset_index()
    )

    # ✅ Save summary file
    emotion_summary.to_csv(SUMMARY_FILE, index=False, encoding="utf-8")
    print(f"💾 Emotion summary saved → {SUMMARY_FILE}")

    print("\n📊 Destination Emotion Overview (sample):")
    print(emotion_summary.head(10))


if __name__ == "__main__":
    main()



#Visualization


# ---------- Use Case 3 Visualization: Emotion Distribution ----------
"""
Visualizes the emotion distribution across destinations
Input : data_raw/usecase3_emotion_summary.csv
Output: data_raw/usecase3_emotion_chart.png
"""

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

# ---------- CONFIG ----------
INPUT_FILE = "data_raw/usecase3_emotion_summary.csv"
OUTPUT_FILE = "data_raw/usecase3_emotion_chart.png"
# ----------------------------

print("🎨 Creating Emotion Distribution Chart...")

# Load the summary data
df = pd.read_csv(INPUT_FILE)

# Melt the dataframe to long format for Seaborn
df_melted = df.melt(id_vars="destination", var_name="emotion", value_name="proportion")

# Set up the style
sns.set(style="whitegrid", font_scale=1.1)

# Create a stacked bar plot
plt.figure(figsize=(14, 7))
sns.barplot(data=df_melted, x="destination", y="proportion", hue="emotion")

plt.title("Emotion Distribution by Destination", fontsize=16, weight="bold")
plt.xlabel("Destination", fontsize=12)
plt.ylabel("Emotion Proportion", fontsize=12)
plt.xticks(rotation=45, ha="right")
plt.legend(title="Emotion", bbox_to_anchor=(1.05, 1), loc='upper left')

plt.tight_layout()

# ✅ Save the figure automatically
os.makedirs("data_raw", exist_ok=True)
plt.savefig(OUTPUT_FILE, dpi=300, bbox_inches="tight")
print(f"💾 Chart saved successfully → {OUTPUT_FILE}")

# Optional: Show it for 5 seconds
plt.show(block=False)
plt.pause(5)
plt.close()
