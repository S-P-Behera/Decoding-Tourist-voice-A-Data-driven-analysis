# tourist_experience_scraper.py
"""
Web Scraper for Tourist Experiences Across India (2025 Compatible)
Scrapes Reddit (travel discussions) + TripAdvisor forums
Saves dataset to: data_raw/tourist_experience_india.csv
"""

import requests
from bs4 import BeautifulSoup
import pandas as pd
from tqdm import tqdm
import os
import time

# ---------------- CONFIG ----------------
OUT_DIR = "data_raw"
OUT_FILE = os.path.join(OUT_DIR, "tourist_experience_india.csv")

DESTINATIONS = [
    "Goa", "Manali", "Kerala", "Rajasthan", "Delhi", "Jaipur", "Agra",
    "Kashmir", "Leh Ladakh", "Darjeeling", "Ooty", "Mysore", "Shimla", "Kolkata"
]
# ----------------------------------------

# ---------- REDDIT SCRAPER -------------
def scrape_reddit(destination, limit=30):
    """Scrapes Reddit using public JSON API"""
    posts = []
    query = f"{destination} travel India"
    url = f"https://www.reddit.com/search.json?q={query}&limit={limit}&sort=relevance"

    headers = {"User-Agent": "Mozilla/5.0"}
    try:
        response = requests.get(url, headers=headers, timeout=10)
        data = response.json()
        children = data.get("data", {}).get("children", [])

        for post in children:
            post_data = post.get("data", {})
            posts.append({
                "source": "Reddit",
                "destination": destination,
                "title": post_data.get("title"),
                "content": post_data.get("selftext", ""),
                "link": "https://www.reddit.com" + post_data.get("permalink", ""),
                "date": time.strftime("%Y-%m-%d", time.gmtime(post_data.get("created_utc", 0)))
            })
    except Exception as e:
        print(f"⚠️ Reddit scraping failed for {destination}: {e}")
    return posts


# ---------- TRIPADVISOR FORUM SCRAPER -------------
def scrape_tripadvisor_forum(destination, pages=2):
    """Scrapes TripAdvisor forum titles for each destination"""
    base = f"https://www.tripadvisor.in/SearchForums?q={destination.replace(' ', '+')}"
    posts = []
    for p in range(pages):
        url = f"{base}&page={p+1}"
        try:
            resp = requests.get(url, headers={"User-Agent": "Mozilla/5.0"}, timeout=10)
            soup = BeautifulSoup(resp.text, "html.parser")
            topics = soup.find_all("div", class_="result-title")
            for t in topics:
                title = t.get_text(strip=True)
                link_tag = t.find("a")
                link = "https://www.tripadvisor.in" + link_tag["href"] if link_tag else None
                if link:
                    posts.append({
                        "source": "TripAdvisor",
                        "destination": destination,
                        "title": title,
                        "content": "",
                        "link": link,
                        "date": ""
                    })
            time.sleep(1)
        except Exception as e:
            print(f"⚠️ TripAdvisor error for {destination}: {e}")
    return posts


# ---------- MAIN SCRAPER LOOP -------------
def main():
    """Main driver function"""
    all_data = []
    os.makedirs(OUT_DIR, exist_ok=True)
    print("🌏 Starting Indian Tourist Experience Scraper...")

    for dest in tqdm(DESTINATIONS, desc="Scraping destinations"):
        reddit_posts = scrape_reddit(dest)
        ta_posts = scrape_tripadvisor_forum(dest)
        all_data.extend(reddit_posts)
        all_data.extend(ta_posts)

    df = pd.DataFrame(all_data)
    df.to_csv(OUT_FILE, index=False, encoding="utf-8")
    print(f"\n✅ Dataset created with {len(df)} records → {OUT_FILE}")

# ---------- ENTRY POINT -------------
if __name__ == "__main__":
    main()
