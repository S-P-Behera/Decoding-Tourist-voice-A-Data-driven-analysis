# usecase5_issue_identification.py
"""
Case 5: Issue Identification + Summarization + Behavior Detection
Now uses SUMY (TextRank Summarizer) instead of Gensim for stable summarization.
"""

import os
import re
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from nltk.sentiment.vader import SentimentIntensityAnalyzer
from tqdm import tqdm
import nltk
from sumy.parsers.plaintext import PlaintextParser
from sumy.nlp.tokenizers import Tokenizer
from sumy.summarizers.text_rank import TextRankSummarizer

# Download NLTK data
nltk.download("vader_lexicon")

# ---------- CONFIG ----------
INPUT_FILE = "data_raw/tourist_experience_cleaned.csv"
ISSUE_FILE = "data_raw/usecase5_detected_issues.csv"
ISSUE_CHART = "data_raw/usecase5_issue_chart.png"
SUMMARY_FILE = "data_raw/usecase5_destination_summary.csv"
BEHAVIOR_FILE = "data_raw/usecase5_behavior_analysis.csv"
# --------------------------------

# Common issue keywords
ISSUE_KEYWORDS = {
    "traffic": ["traffic", "road jam", "jammed", "busy road"],
    "crowd": ["crowd", "crowded", "rush", "noisy"],
    "service": ["poor service", "bad service", "rude staff", "unhelpful"],
    "cleanliness": ["dirty", "unclean", "waste", "smell", "garbage", "pollution"],
    "food": ["bad food", "cold food", "not fresh", "stale"],
    "safety": ["unsafe", "danger", "theft", "scam", "cheated"],
    "price": ["expensive", "overpriced", "costly"],
    "weather": ["rain", "heat", "cold", "too hot", "too cold"],
    "infrastructure": ["bad roads", "broken road", "construction", "delay"]
}

sia = SentimentIntensityAnalyzer()

def detect_issues(row):
    text = row.lower()
    detected = []
    for issue, keywords in ISSUE_KEYWORDS.items():
        for kw in keywords:
            if re.search(rf"\b{re.escape(kw)}\b", text):
                detected.append(issue)
                break
    return detected

def summarize_reviews(texts):
    """Summarize reviews for a destination using TextRank."""
    text = ". ".join(texts)
    try:
        parser = PlaintextParser.from_string(text, Tokenizer("english"))
        summarizer = TextRankSummarizer()
        summary_sentences = summarizer(parser.document, 3)  # 3 sentences summary
        summary = " ".join(str(sentence) for sentence in summary_sentences)
        if not summary.strip():
            summary = "Not enough content to summarize."
    except Exception:
        summary = "Not enough content to summarize."
    return summary

def classify_behavior(text, score):
    """Classify behavior based on sentiment & keywords."""
    text = text.lower()
    if score <= -0.2:
        if any(w in text for w in ["bad", "poor", "dirty", "scam", "unsafe", "worst", "hate"]):
            return "Complaint"
    elif score >= 0.4:
        if any(w in text for w in ["love", "amazing", "great", "beautiful", "recommend", "best", "enjoyed"]):
            return "Recommendation"
    return "Neutral"

def main():
    print("🧭 Starting Case 5: Issue Identification + Summarization + Behavior Detection...")
    df = pd.read_csv(INPUT_FILE)
    print(f"📄 Loaded {len(df)} cleaned reviews")

    tqdm.pandas()

    # ---------- STEP 1: SENTIMENT + ISSUE DETECTION ----------
    df["sentiment_score"] = df["clean_text"].progress_apply(lambda x: sia.polarity_scores(str(x))["compound"])
    neg_df = df[df["sentiment_score"] < -0.1].copy()
    print(f"⚠️ Found {len(neg_df)} negative reviews")

    neg_df["detected_issues"] = neg_df["clean_text"].progress_apply(detect_issues)
    neg_df = neg_df.explode("detected_issues").dropna(subset=["detected_issues"])

    issue_counts = neg_df["detected_issues"].value_counts().reset_index()
    issue_counts.columns = ["issue_type", "count"]

    os.makedirs("data_raw", exist_ok=True)
    issue_counts.to_csv(ISSUE_FILE, index=False, encoding="utf-8")
    print(f"💾 Issues saved → {ISSUE_FILE}")

    plt.figure(figsize=(8,5))
    sns.barplot(x="count", y="issue_type", data=issue_counts, palette="flare")
    plt.title("Most Frequent Tourist Issues (Negative Reviews)", fontsize=14, weight="bold")
    plt.xlabel("Frequency")
    plt.ylabel("Issue Type")
    plt.tight_layout()
    plt.savefig(ISSUE_CHART, dpi=300)
    plt.show(block=False)
    plt.pause(3)
    plt.close()
    print(f"💾 Issue chart saved → {ISSUE_CHART}")

    # ---------- STEP 2: SUMMARIZATION ----------
    print("\n🧾 Generating destination summaries...")
    summaries = []
    for dest, group in tqdm(df.groupby("destination")):
        texts = group["clean_text"].dropna().tolist()
        summary = summarize_reviews(texts)
        avg_sentiment = group["sentiment_score"].mean()
        summaries.append({
            "destination": dest,
            "summary": summary,
            "average_sentiment": round(avg_sentiment, 3)
        })

    summary_df = pd.DataFrame(summaries)
    summary_df.to_csv(SUMMARY_FILE, index=False, encoding="utf-8")
    print(f"💾 Destination summaries saved → {SUMMARY_FILE}")

    # ---------- STEP 3: BEHAVIOR / INTENT DETECTION ----------
    print("\n🎭 Performing behavior / intent classification...")
    df["behavior_label"] = df.progress_apply(lambda row: classify_behavior(str(row["clean_text"]), row["sentiment_score"]), axis=1)
    behavior_counts = df["behavior_label"].value_counts().reset_index()
    behavior_counts.columns = ["behavior_type", "count"]

    behavior_counts.to_csv(BEHAVIOR_FILE, index=False, encoding="utf-8")
    print(f"💾 Behavior analysis saved → {BEHAVIOR_FILE}")

    # Visualization
    plt.figure(figsize=(6,5))
    sns.barplot(x="count", y="behavior_type", data=behavior_counts, palette="coolwarm")
    plt.title("Tourist Review Behavior Classification", fontsize=14, weight="bold")
    plt.xlabel("Number of Reviews")
    plt.ylabel("Behavior Type")
    plt.tight_layout()
    plt.savefig("data_raw/usecase5_behavior_chart.png", dpi=300)
    plt.show(block=False)
    plt.pause(3)
    plt.close()
    print("💾 Behavior chart saved → data_raw/usecase5_behavior_chart.png")

    print("\n✅ Case 5 Completed Successfully — Issues, Summaries & Behaviors Generated!")

if __name__ == "__main__":
    main()
