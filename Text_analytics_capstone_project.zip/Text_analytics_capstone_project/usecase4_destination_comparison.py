# usecase4_topic_detection.py
"""
Improved Topic Detection for Tourist Reviews
- Uses TF-IDF + NMF with ngrams (1,2)
- Uses stronger stopword filtering (including destination names)
Outputs:
 - data_raw/usecase4_topic_keywords.csv
 - data_raw/usecase4_topic_chart.png (with topic names)
 - data_raw/usecase4_topic_labeled.csv
 - data_raw/usecase4_topic_named.csv
"""

import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import NMF
import nltk

# ensure stopwords
nltk.download("stopwords")
from nltk.corpus import stopwords

# ---------- CONFIG ----------
INPUT_FILE = "data_raw/tourist_experience_cleaned.csv"
TOPIC_FILE = "data_raw/usecase4_topic_keywords.csv"
CHART_FILE = "data_raw/usecase4_topic_chart.png"
NUM_TOPICS = 6
NUM_WORDS = 10
MIN_DF = 4
MAX_DF = 0.80
MAX_FEATURES = 3000
# --------------------------------

# base stopwords + additions (fillers, pronouns, and destination names)
base_sw = set(stopwords.words("english"))
extra_sw = {
    "like","time","trip","really","people","experience","im","dont",
    "would","could","also","one","get","go","going","went","day","days",
    "much","many","went","amp","ive","ya","us","use"
}
location_names = {
    "goa","manali","kerala","rajasthan","delhi","jaipur","agra",
    "kashmir","leh","ladakh","darjeeling","ooty","mysore","shimla","kolkata"
}
all_stopwords = list(base_sw.union(extra_sw).union(location_names))

def preprocess_texts(texts):
    """Light text cleaning: remove non-ascii chars and extra spaces"""
    cleaned = []
    for t in texts:
        if not isinstance(t, str):
            t = ""
        s = t.encode("ascii", "ignore").decode("utf-8")
        s = " ".join(s.split())
        cleaned.append(s)
    return cleaned

def extract_topics_tfidf_nmf(docs, n_topics=NUM_TOPICS, n_words=NUM_WORDS):
    vectorizer = TfidfVectorizer(
        stop_words=all_stopwords,
        ngram_range=(1,2),
        max_df=MAX_DF,
        min_df=MIN_DF,
        max_features=MAX_FEATURES
    )
    X = vectorizer.fit_transform(docs)

    nmf = NMF(n_components=n_topics, random_state=42, init="nndsvda", max_iter=400)
    W = nmf.fit_transform(X)
    H = nmf.components_

    feature_names = vectorizer.get_feature_names_out()
    topics = []
    for topic_idx, topic in enumerate(H):
        top_indices = topic.argsort()[-n_words:][::-1]
        top_words = [feature_names[i] for i in top_indices]
        topics.append({"Topic_ID": f"Topic {topic_idx+1}", "Top_Words": ", ".join(top_words)})
    return topics, nmf, vectorizer, W

def main():
    print("🧭 Running improved TF-IDF + NMF topic detection...")
    df = pd.read_csv(INPUT_FILE)
    print(f"📄 Loaded {len(df)} records")

    docs = preprocess_texts(df["clean_text"].fillna("").tolist())

    topics, model, vectorizer, doc_topic_matrix = extract_topics_tfidf_nmf(
        docs, n_topics=NUM_TOPICS, n_words=NUM_WORDS
    )

    topic_df = pd.DataFrame(topics)
    os.makedirs("data_raw", exist_ok=True)
    topic_df.to_csv(TOPIC_FILE, index=False, encoding="utf-8")
    print(f"💾 Topics saved → {TOPIC_FILE}")
    print("\n🧠 Topics (top words):")
    print(topic_df)

    # Assign dominant topic per document
    df["Dominant_Topic"] = doc_topic_matrix.argmax(axis=1) + 1  # 1-index topics

    # ---------- HUMAN-FRIENDLY TOPIC LABELS ----------
    topic_labels = {
        1: "Logistics & Essentials",
        2: "Culture & Food",
        3: "General Destinations",
        4: "Hotels & Seasonal Trips",
        5: "Solo & Safe Travel",
        6: "Events & Group Travel"
    }
    df["Topic_Label"] = df["Dominant_Topic"].map(topic_labels)

    # ---------- SAVE LABELED FILES ----------
    labeled_file = "data_raw/usecase4_topic_labeled.csv"
    named_file = "data_raw/usecase4_topic_named.csv"
    df.to_csv(labeled_file, index=False, encoding="utf-8")
    df.to_csv(named_file, index=False, encoding="utf-8")
    print(f"💾 Named topics saved → {named_file}")
    print(f"💾 Labeled reviews saved → {labeled_file}")

    # ---------- VISUALIZATION ----------
    topic_counts = df["Topic_Label"].value_counts().sort_values(ascending=False)
    plt.figure(figsize=(9,5))
    sns.barplot(
        y=topic_counts.index,
        x=topic_counts.values,
        palette="crest"
    )
    plt.title("Topic Distribution Across Reviews", fontsize=14, weight="bold")
    plt.xlabel("Number of Reviews")
    plt.ylabel("Topic Name")
    plt.tight_layout()
    plt.savefig(CHART_FILE, dpi=300)
    plt.show(block=False)
    plt.pause(4)
    plt.close()
    print(f"💾 Topic distribution chart saved → {CHART_FILE}")
    print("\n✅ Topic Detection Completed Successfully!")

if __name__ == "__main__":
    main()
