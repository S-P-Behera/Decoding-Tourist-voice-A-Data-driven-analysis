# usecase2_keyword_extraction.py
"""
Use Case 2: Keyword Extraction from Tourist Reviews (YAKE)
Input : data_raw/tourist_experience_cleaned.csv
Output: data_raw/usecase2_keyword_extraction.csv
"""

import pandas as pd
import yake
import os
from tqdm import tqdm

INPUT_FILE = "data_raw/tourist_experience_cleaned.csv"
OUTPUT_FILE = "data_raw/usecase2_keyword_extraction.csv"

def extract_keywords(text, max_keywords=10):
    """Extract top keywords using YAKE"""
    kw_extractor = yake.KeywordExtractor(
        lan="en", n=1, dedupLim=0.9, top=max_keywords, features=None
    )
    try:
        keywords = kw_extractor.extract_keywords(text)
        sorted_keywords = [kw for kw, score in sorted(keywords, key=lambda x: x[1])]
        return ", ".join(sorted_keywords)
    except Exception:
        return ""

def main():
    print("🔍 Starting Keyword Extraction (YAKE)...")
    df = pd.read_csv(INPUT_FILE)
    print(f"📄 Loaded {len(df)} cleaned reviews")

    tqdm.pandas()
    df["keywords"] = df["clean_text"].progress_apply(lambda x: extract_keywords(str(x)))

    # Group keywords by destination
    grouped = (
        df.groupby("destination")["keywords"]
        .apply(lambda x: ", ".join(x))
        .reset_index()
    )

    # Extract most frequent keywords per destination
    top_keywords = []
    for _, row in grouped.iterrows():
        dest = row["destination"]
        all_keywords = row["keywords"].split(", ")
        freq = pd.Series(all_keywords).value_counts().head(10)
        top_keywords.append({
            "destination": dest,
            "top_keywords": ", ".join(freq.index)
        })

    result_df = pd.DataFrame(top_keywords)
    os.makedirs("data_raw", exist_ok=True)
    result_df.to_csv(OUTPUT_FILE, index=False, encoding="utf-8")

    print(f"✅ Keyword extraction complete → {OUTPUT_FILE}")
    print(result_df.head(10))

if __name__ == "__main__":
    main()
    
    
    #Visualization
    
# ---------- Visualization for Use Case 2: Keyword Extraction (All Destinations) ----------
import pandas as pd
import matplotlib.pyplot as plt
import os

# Load the keyword extraction results
df = pd.read_csv("data_raw/usecase2_keyword_extraction.csv")

# Create a directory for saving (if not already exists)
os.makedirs("data_raw", exist_ok=True)

# Build a text summary for all destinations
plt.figure(figsize=(12, 8))
for idx, row in df.iterrows():
    destination = row["destination"]
    keywords = row["top_keywords"].split(", ")[:5]  # top 5 keywords for readability
    text_block = ", ".join(keywords)
    plt.text(0.05, 1 - (idx * 0.06), f"{destination}: {text_block}",
             fontsize=10, fontfamily='monospace')

plt.axis("off")
plt.title("Top Keywords Mentioned by Tourists (All Destinations)", fontsize=14, fontweight="bold")
plt.tight_layout()

# 💾 Save the combined visualization
save_path = "data_raw/usecase2_all_keywords_chart.png"
plt.savefig(save_path, dpi=300)
plt.show(block=False)
plt.pause(5)
plt.close()

print(f"✅ Combined keyword chart saved successfully → {save_path}")




