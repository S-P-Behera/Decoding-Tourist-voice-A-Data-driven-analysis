# data_cleaning.py
"""
Clean scraped tourist experience data.
Input : data_raw/tourist_experience_india.csv
Output: data_raw/tourist_experience_cleaned.csv
"""

import os
import re
import string
import time
import pandas as pd
import nltk
from nltk.corpus import stopwords
from tqdm import tqdm

# config
RAW_FILE = "data_raw/tourist_experience_india.csv"
CLEAN_FILE = "data_raw/tourist_experience_cleaned.csv"

# Ensure NLTK stopwords are present (will skip if already downloaded)
try:
    _ = stopwords.words("english")
except LookupError:
    nltk.download("stopwords")
    nltk.download("punkt")

STOPWORDS = set(stopwords.words("english"))

def basic_clean(text):
    """Basic cleaning: ensure string, remove urls, mentions, punctuation, digits, extra spaces"""
    if not isinstance(text, str):
        return ""
    # Remove URLs
    text = re.sub(r"http\S+|www\S+|https\S+", " ", text)
    # Remove mentions and hashtags
    text = re.sub(r"@\w+|#\w+", " ", text)
    # Remove emojis / non-ascii
    text = text.encode("ascii", "ignore").decode("utf-8")
    # Remove punctuation and numbers
    text = text.translate(str.maketrans("", "", string.punctuation + string.digits))
    # Lowercase
    text = text.lower()
    # Normalize whitespace
    text = re.sub(r"\s+", " ", text).strip()
    return text

def remove_stopwords(text):
    """Remove stopwords, keep short words that carry meaning (2+ chars)"""
    if not text:
        return ""
    tokens = text.split()
    filtered = [t for t in tokens if (t not in STOPWORDS) and len(t) > 1]
    return " ".join(filtered)

def clean_pipeline(text):
    """Full pipeline: basic_clean -> remove_stopwords"""
    t = basic_clean(text)
    t = remove_stopwords(t)
    return t

def load_dataframe(path):
    """Load CSV with safe defaults and print info"""
    print(f"Loading {path} ...")
    df = pd.read_csv(path, dtype=str, encoding="utf-8", low_memory=False)
    print(f"Loaded {len(df)} rows. Columns: {list(df.columns)}")
    return df

def prepare_full_text(df, title_col="title", content_col="content"):
    """Combine title & content / fallback to other column names if necessary"""
    # handle missing columns
    if title_col not in df.columns and content_col not in df.columns:
        # try common alternatives
        alt_title = None
        alt_content = None
        for c in df.columns:
            if "title" in c.lower() and not alt_title:
                alt_title = c
            if ("content" in c.lower() or "text" in c.lower() or "body" in c.lower()) and not alt_content:
                alt_content = c
        title_col = alt_title
        content_col = alt_content

    # create full_text
    df["full_text"] = ""
    tcol = title_col if title_col in df.columns else None
    ccol = content_col if content_col in df.columns else None

    if tcol and ccol:
        df["full_text"] = (df[tcol].fillna("") + " " + df[ccol].fillna("")).str.strip()
    elif ccol:
        df["full_text"] = df[ccol].fillna("").str.strip()
    elif tcol:
        df["full_text"] = df[tcol].fillna("").str.strip()
    else:
        # fallback: concat all string cols
        textcols = [c for c in df.columns if df[c].dtype == object]
        df["full_text"] = df[textcols].apply(lambda row: " ".join([str(x) for x in row if pd.notna(x)]), axis=1)

    return df

def run_cleaning():
    df = load_dataframe(RAW_FILE)

    # combine title + content into full_text
    df = prepare_full_text(df, title_col="title", content_col="content")

    # quick sanity checks before cleaning
    print("Sample raw texts:")
    print(df["full_text"].dropna().head(3).to_list())

    # apply cleaning pipeline
    tqdm.pandas()
    df["clean_text"] = df["full_text"].progress_apply(clean_pipeline)

    # drop empties / very short texts
    df = df[df["clean_text"].str.len() > 10].copy()

    # keep columns we need for NLP
    keep_cols = []
    for c in ["source", "destination", "clean_text", "link", "date"]:
        if c in df.columns:
            keep_cols.append(c)
    # if some columns missing, always include clean_text
    if "clean_text" not in keep_cols:
        keep_cols.append("clean_text")

    cleaned_df = df[keep_cols].reset_index(drop=True)

    # Save cleaned csv
    os.makedirs(os.path.dirname(CLEAN_FILE) or ".", exist_ok=True)
    cleaned_df.to_csv(CLEAN_FILE, index=False, encoding="utf-8")
    print(f"Saved cleaned file ({len(cleaned_df)} rows) -> {CLEAN_FILE}")

if __name__ == "__main__":
    start = time.time()
    run_cleaning()
    print("Done in %.2f sec" % (time.time() - start))
